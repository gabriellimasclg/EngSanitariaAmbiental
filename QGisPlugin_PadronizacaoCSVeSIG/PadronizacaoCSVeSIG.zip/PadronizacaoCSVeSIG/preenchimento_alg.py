# -*- coding: utf-8 -*-
"""
Algoritmo de processamento QGIS - Preencher e Padronizar (Modelo Semente)
Autor: Gabriel Coimbra / Nova Engevix
Compatível com QGIS 3.34+
pandas + shapely + PyQGIS
"""

from datetime import datetime, date, time
import pandas as pd
import json
import time
import urllib.parse
import urllib.request

from qgis.PyQt.QtCore import QByteArray
from qgis.PyQt.QtCore import QVariant
from qgis.core import (
    QgsProcessingAlgorithm,
    QgsProcessingParameterVectorLayer,
    QgsProcessingParameterString,
    QgsProcessingParameterFeatureSink,
    QgsProcessingException,
    QgsProcessing,
    QgsWkbTypes,
    QgsFields, QgsField, QgsFeature, QgsGeometry,
    QgsCoordinateTransform, QgsProject,           # <-- novo
    QgsMessageLog, Qgis,
    NULL
    
)

from qgis.core import QgsDistanceArea
from shapely import wkb as shwkb
from shapely.geometry import (
    Point, MultiPoint, LineString, MultiLineString,
    Polygon, MultiPolygon
)


# ----------------------------------------------------------------------
# FUNÇÕES AUXILIARES
# ----------------------------------------------------------------------

import unicodedata
import re
import os
import urllib.parse

def _geom_to_latlon_wgs84(qgs_geom, crs_src, context) -> tuple:
    """
    Retorna (lat, lon) em EPSG:4326 usando o PRIMEIRO VÉRTICE da geometria.
    Funciona para ponto/linha/polígono/multipart.
    """
    if qgs_geom is None or qgs_geom.isEmpty():
        return (None, None)

    # pega o primeiro vértice disponível (serve para qualquer tipo)
    try:
        it = qgs_geom.vertices()
        p = next(it, None)
        if p is None:
            return (None, None)

        # transforma CRS -> WGS84
        from qgis.core import QgsCoordinateReferenceSystem, QgsCoordinateTransform, QgsPointXY
        crs_wgs = QgsCoordinateReferenceSystem("EPSG:4326")
        tr = QgsCoordinateTransform(crs_src, crs_wgs, context.transformContext())

        p2 = tr.transform(QgsPointXY(p))
        lon, lat = p2.x(), p2.y()
        return (lat, lon)

    except Exception:
        return (None, None)



def _coord_cache_key(lat, lon, casas=5):
    if lat is None or lon is None:
        return None
    return (round(float(lat), casas), round(float(lon), casas))


def _extract_bairro_from_nominatim_json(data: dict):
    """
    Mesma lógica do teu script: suburb/neighbourhood/...
    """
    if not data or not isinstance(data, dict):
        return None
    addr = data.get("address") or {}
    return (
        addr.get("suburb")
        or addr.get("neighbourhood")
        or addr.get("city_district")
        or addr.get("quarter")
        or addr.get("village")
        or addr.get("town")
        or addr.get("city")
    )


def _nominatim_reverse(lat, lon, language="pt", user_agent="padrao_cliente_qgis", timeout=20):
    """
    Reverse geocode via Nominatim (OSM). Retorna bairro (str) ou None.
    """
    params = {
        "format": "jsonv2",
        "lat": str(lat),
        "lon": str(lon),
        "zoom": "18",
        "addressdetails": "1",
        "accept-language": language,
    }
    url = "https://nominatim.openstreetmap.org/reverse?" + urllib.parse.urlencode(params)

    req = urllib.request.Request(
        url,
        headers={
            "User-Agent": user_agent,
            "Accept": "application/json",
        },
        method="GET",
    )

    with urllib.request.urlopen(req, timeout=timeout) as resp:
        raw = resp.read().decode("utf-8", errors="strict")
        data = json.loads(raw)
        return _extract_bairro_from_nominatim_json(data)


def _extract_csv_path_from_layer(tbl_layer) -> str:
    """
    Extrai o caminho do CSV a partir do source() da camada.
    Funciona para:
      - delimitedtext: file:///C:/.../E.csv?...
      - ogr: C:/.../E.csv
    """
    src = (tbl_layer.source() or "").strip()

    # caso file:///...
    if src.lower().startswith("file:"):
        # separa querystring (?...) e decodifica %20 etc.
        p = src.split("?", 1)[0]
        p = urllib.parse.unquote(p)

        # remove prefixos file:///
        if p.lower().startswith("file:///"):
            p = p[8:]  # remove 'file:///'
        elif p.lower().startswith("file://"):
            p = p[7:]
        return p

    # caso já seja caminho direto
    return src


def _read_csv_robust(path: str, feedback=None) -> pd.DataFrame:
    """
    Lê CSV com fallback de encoding e separador ';' (o seu padrão).
    """
    if not os.path.exists(path):
        raise QgsProcessingException(f"CSV não encontrado: {path}")

    # tentativa 1: UTF-8 (sem BOM)
    try:
        df = pd.read_csv(path, sep=";", dtype=str, encoding="utf-8", keep_default_na=False)
        if feedback: feedback.pushInfo("CSV lido via pandas (encoding=utf-8).")
        return df
    except Exception:
        pass

    # tentativa 2: UTF-8 com BOM
    try:
        df = pd.read_csv(path, sep=";", dtype=str, encoding="utf-8-sig", keep_default_na=False)
        if feedback: feedback.pushInfo("CSV lido via pandas (encoding=utf-8-sig).")
        return df
    except Exception:
        pass

    # tentativa 3: CP1252 (bem comum no Windows/Excel)
    try:
        df = pd.read_csv(path, sep=";", dtype=str, encoding="cp1252", keep_default_na=False)
        if feedback: feedback.pushInfo("CSV lido via pandas (encoding=cp1252).")
        return df
    except Exception as e:
        raise QgsProcessingException(f"Falha ao ler CSV via pandas com encodings padrão. Erro: {e}")



def _to_unicode(v, enc_hint="utf-8"):
    """
    Garante que v vira str (unicode) SEM criar '�'.
    Se vier bytes/QByteArray, decodifica com enc_hint e fallbacks.
    """
    if v is None:
        return None

    # QVariant -> valor bruto
    try:
        if isinstance(v, QVariant):
            if v.isNull():
                return None
            v = v.value()
    except Exception:
        pass

    # QByteArray -> bytes
    try:
        if isinstance(v, QByteArray):
            v = bytes(v)
    except Exception:
        pass

    # bytes -> decode com fallbacks (sem errors="replace")
    if isinstance(v, (bytes, bytearray)):
        for enc in (enc_hint, "utf-8", "cp1252", "latin-1"):
            try:
                return v.decode(enc)
            except Exception:
                pass
        # último fallback (aqui sim “perde”, mas evita crash)
        return v.decode(enc_hint, errors="ignore")

    # já é str
    if isinstance(v, str):
        return v

    return str(v)


# Liga/desliga fácil (depois você pode colocar como parâmetro do algoritmo)
SANITIZE_TEXT_ASCII = True

def _sanitize_text_ascii(s: str) -> str:
    """
    Converte para ASCII simples:
    - remove acentos (Implantação -> Implantacao)
    - remove caracteres estranhos (� etc)
    - mantém apenas ASCII imprimível (opcionalmente você pode manter pontuação)
    """
    if s is None:
        return None

    # garante string
    if not isinstance(s, str):
        s = str(s)

    # normaliza unicode e remove diacríticos
    s = unicodedata.normalize("NFKD", s)
    s = "".join(ch for ch in s if not unicodedata.combining(ch))

    # troca caracteres “lixo” comuns
    s = s.replace("�", "")

    # mantém apenas ASCII (remove qualquer coisa fora)
    s = s.encode("ascii", errors="ignore").decode("ascii", errors="ignore")

    # (opcional) limpa controles e espaços estranhos
    s = re.sub(r"[\x00-\x1F\x7F]", "", s).strip()

    return s


def _maybe_sanitize_text(value):
    """Aplica sanitização apenas quando for string e o flag estiver ligado."""
    if not SANITIZE_TEXT_ASCII:
        return value
    if value is None:
        return None
    if isinstance(value, str):
        return _sanitize_text_ascii(value)
    return value

def _is_empty_like(v) -> bool:
    """
    True se o valor deve ser tratado como vazio (e portanto pode ser preenchido).
    Não considera 0 como vazio.
    """
    v = _clean_empty(v)  # converte QVariant null, NULL, '', 'null', etc -> None
    if v is None:
        return True

    # strings tipo "   "
    if isinstance(v, str) and v.strip() == "":
        return True

    return False


def _clean_empty(v):
    """Converte valores 'vazios' para None: pd.NA, NaN, '', 'NULL', NULL(QGIS), QVariant NULL, etc."""

    # QVariant nulo (muito comum vindo de feat[field])
    try:
        if isinstance(v, QVariant) and v.isNull():
            return None
        v = v.value()
    except Exception:
        pass

    # NULL do QGIS (sentinela)
    try:
        if v is NULL:
            return None
    except Exception:
        pass

    try:
        import pandas as _pd
        if _pd.isna(v):
            return None
    except Exception:
        pass

    if v is None:
        return None
    if isinstance(v, float) and (v != v):  # NaN
        return None

    if isinstance(v, str):
        s = v.strip()
        if s == "":
            return None
        if s.lower() in ("null", "<null>", "none", "<none>", "nan", "<na>", "na", "n/a"):
            return None

    return v

def _truncate_utf8_safe(s: str, max_len: int) -> str:
    """
    Trunca string respeitando UTF-8: corta por bytes e decodifica ignorando
    bytes incompletos no final (evita '�').
    """
    if s is None or max_len is None or max_len <= 0:
        return s
    if not isinstance(s, str):
        s = str(s)

    b = s.encode("utf-8")
    if len(b) <= max_len:
        return s

    return b[:max_len].decode("utf-8", errors="ignore")


def _coerce_to_type(v, qvtype):
    """
    Converte valor Python para o tipo esperado pelo campo do QGIS (QVariant).
    Suporta:
      - Date: "2024" -> 2024-01-01 ; "03/2024" ou "2024-03" -> 2024-03-01
      - DateTime: idem, com 00:00:00
    """
    from datetime import datetime, date, time
    import re

    def _to_int(x):
        # cobre "2026", "2026.0", 2026.0
        try:
            if isinstance(x, str):
                x = x.replace(",", ".")
            f = float(x)
            return int(round(f))
        except Exception:
            return None

    def _parse_year_or_month_year_to_date(s):
        s = str(s).strip()
        # Ano puro (quatro dígitos)
        if re.fullmatch(r"\d{4}", s):
            return date(int(s), 1, 1)
        # "MM/AAAA" | "M/AAAA" | "AAAA-MM" | "AAAA-M"
        m = re.fullmatch(r"(\d{1,2})[/-](\d{4})", s)  # MM-AAAA ou MM/AAAA
        if m:
            mm, yyyy = int(m.group(1)), int(m.group(2))
            if 1 <= mm <= 12:
                return date(yyyy, mm, 1)
        m = re.fullmatch(r"(\d{4})[/-](\d{1,2})", s)  # AAAA-MM ou AAAA/M
        if m:
            yyyy, mm = int(m.group(1)), int(m.group(2))
            if 1 <= mm <= 12:
                return date(yyyy, mm, 1)
        return None

    v = _clean_empty(v)
    if v is None:
        return None

    try:
        # --- Inteiros / Doubles / Bool
        if qvtype in (QVariant.Int, QVariant.UInt, QVariant.LongLong, QVariant.ULongLong):
            iv = _to_int(v)
            return iv if iv is not None else None

        if qvtype in (QVariant.Double,):
            if isinstance(v, str):
                v = v.replace(",", ".")
            return float(v)

        if qvtype in (QVariant.Bool,):
            if isinstance(v, str):
                return v.strip().lower() in ("1", "true", "t", "yes", "y", "sim")
            return bool(v)

        # --- Date
        if qvtype in (QVariant.Date,):
            # já é date/datetime
            if isinstance(v, date) and not isinstance(v, datetime):
                return v
            if isinstance(v, datetime):
                return v.date()
            # ano puro ou mês/ano
            d = _parse_year_or_month_year_to_date(v)
            if d:
                return d
            # inteiro numérico (ex: 2026.0 vindo do Excel)
            iv = _to_int(v)
            if iv is not None and 1000 <= iv <= 9999:
                return date(iv, 1, 1)
            # formatos completos
            if isinstance(v, str):
                for fmt in ("%Y-%m-%d", "%d/%m/%Y", "%m/%d/%Y"):
                    try:
                        return datetime.strptime(v.strip(), fmt).date()
                    except Exception:
                        pass
            return None

        # --- DateTime
        if qvtype in (QVariant.DateTime,):
            if isinstance(v, datetime):
                return v
            if isinstance(v, date):
                return datetime(v.year, v.month, v.day)
            d = _parse_year_or_month_year_to_date(v)
            if d:
                return datetime(d.year, d.month, d.day)
            iv = _to_int(v)
            if iv is not None and 1000 <= iv <= 9999:
                return datetime(iv, 1, 1, 0, 0, 0)
            if isinstance(v, str):
                for fmt in ("%Y-%m-%d %H:%M:%S", "%d/%m/%Y %H:%M:%S", "%Y-%m-%dT%H:%M:%S",
                            "%Y-%m-%d", "%d/%m/%Y", "%m/%d/%Y"):
                    try:
                        dt = datetime.strptime(v.strip(), fmt)
                        if fmt in ("%Y-%m-%d", "%d/%m/%Y", "%m/%d/%Y"):
                            return datetime(dt.year, dt.month, dt.day, 0, 0, 0)
                        return dt
                    except Exception:
                        pass
            return None

        # --- Time
        if qvtype in (QVariant.Time,):
            if isinstance(v, time):
                return v
            if isinstance(v, str):
                for fmt in ("%H:%M:%S", "%H:%M"):
                    try:
                        return datetime.strptime(v.strip(), fmt).time()
                    except Exception:
                        pass
            return None

        # --- Texto

        if isinstance(v, bytes):
            # tenta decodificações comuns (sem destruir se já estiver ok)
            for enc in ("utf-8", "cp1252", "latin-1"):
                try:
                    return v.decode(enc)
                except Exception:
                    pass
            return v.decode("utf-8", errors="replace")

        s = v if isinstance(v, str) else str(v)

        return s

    except Exception:
        return None


def _ajustar_geom_para_tipo(g, geom_exp: str):
    """Converte a geometria shapely 'g' para o tipo 'geom_exp' quando possível."""
    if g is None:
        return None
    exp = (geom_exp or "").lower()
    gtype = (getattr(g, "geom_type", "") or "").lower()

    # Pontos
    if exp == "point":
        if gtype == "point":
            return g
        if gtype == "multipoint":
            geoms = list(g.geoms)
            return geoms[0] if geoms else None
        return g

    if exp == "multipoint":
        if gtype == "point":
            return MultiPoint([g])
        if gtype == "multipoint":
            return g
        return g

    # Linhas
    if exp == "linestring":
        if gtype == "linestring":
            return g
        if gtype == "multilinestring":
            geoms = list(g.geoms)
            return geoms[0] if geoms else None
        return g

    if exp == "multilinestring":
        if gtype == "linestring":
            return MultiLineString([g])
        if gtype == "multilinestring":
            return g
        return g

    # Polígonos
    if exp == "polygon":
        if gtype == "polygon":
            return g
        if gtype == "multipolygon":
            geoms = list(g.geoms)
            return max(geoms, key=lambda p: p.area) if geoms else None
        return g

    if exp == "multipolygon":
        if gtype == "polygon":
            return MultiPolygon([g])
        if gtype == "multipolygon":
            return g
        return g

    return g


def _layer_to_dataframe(vl, want_geometry=False):
    """Converte uma QgsVectorLayer em pandas.DataFrame. Se want_geometry=True,
    inclui coluna '__geometry__' com objetos shapely (ou None)."""
    fields = [f.name() for f in vl.fields()]
    rows = []
    for feat in vl.getFeatures():
        row = {name: feat[name] for name in fields}
        if want_geometry and feat.hasGeometry():
            try:
                row["__geometry__"] = shwkb.loads(bytes(feat.geometry().asWkb()))
            except Exception:
                row["__geometry__"] = None
        elif want_geometry:
            row["__geometry__"] = None
        rows.append(row)
    df = pd.DataFrame(rows)
    return df


def _expected_geom_from_layer(layer):
    """Retorna 'point'/'multipoint'/'linestring'/'multilinestring'/'polygon'/'multipolygon' para a camada dada."""
    wkb = layer.wkbType()
    is_multi = QgsWkbTypes.isMultiType(wkb)
    gtype = QgsWkbTypes.geometryType(wkb)

    if gtype == QgsWkbTypes.PointGeometry:
        return "multipoint" if is_multi else "point"
    if gtype == QgsWkbTypes.LineGeometry:
        return "multilinestring" if is_multi else "linestring"
    if gtype == QgsWkbTypes.PolygonGeometry:
        return "multipolygon" if is_multi else "polygon"
    return ""  # unknown / NoGeometry


def _pick(row, name):
    """Pega valor de 'name', lidando com colisões de merge (_x/_y)."""
    if name in row:
        return row[name]
    if f"{name}_x" in row and pd.notna(row[f"{name}_x"]):
        return row[f"{name}_x"]
    if f"{name}_y" in row and pd.notna(row[f"{name}_y"]):
        return row[f"{name}_y"]
    return None

def _layer_to_lookup(layer, key_field: str):
    """
    Retorna dict: { key: {col: valor, ...} } preservando valores do QGIS.
    """
    lookup = {}
    fields = [f.name() for f in layer.fields()]

    for feat in layer.getFeatures():
        k = feat[key_field]
        k = _clean_empty(k)
        if k is None:
            continue
        k = str(k).strip()

        row = {}
        for name in fields:
            row[name] = feat[name]  # mantém o valor "cru" do QGIS
        lookup[k] = row

    return lookup

def _bairro_point_from_geometry(qgs_geom, crs_src, context):
    """
    Retorna (lat, lon) em EPSG:4326 seguindo a regra:
    - Point → o próprio ponto
    - Line / MultiLine → PRIMEIRO VÉRTICE
    - Polygon / MultiPolygon → pointOnSurface()
    """
    if qgs_geom is None or qgs_geom.isEmpty():
        return (None, None)

    gtype = QgsWkbTypes.geometryType(qgs_geom.wkbType())

    try:
        # Polígono → pointOnSurface (garantido dentro)
        if gtype == QgsWkbTypes.PolygonGeometry:
            p = qgs_geom.pointOnSurface().asPoint()

        # Linha ou ponto → primeiro vértice
        else:
            it = qgs_geom.vertices()
            p = next(it, None)
            if p is None:
                return (None, None)

        # Transformar para WGS84
        from qgis.core import QgsCoordinateReferenceSystem, QgsCoordinateTransform, QgsPointXY
        crs_wgs = QgsCoordinateReferenceSystem("EPSG:4326")
        tr = QgsCoordinateTransform(crs_src, crs_wgs, context.transformContext())

        p2 = tr.transform(QgsPointXY(p))
        lon, lat = p2.x(), p2.y()
        return (lat, lon)

    except Exception:
        return (None, None)


# ----------------------------------------------------------------------
# CLASSE PRINCIPAL: O Algoritmo de Processamento
# ----------------------------------------------------------------------
class PreencherDeSementeAlgorithm(QgsProcessingAlgorithm):
    INPUT_LAYER = 'INPUT_LAYER'
    SEED_LAYER = 'SEED_LAYER'
    TABLE_LAYER = 'TABLE_LAYER'
    GIS_KEY = 'GIS_KEY'
    XLS_KEY = 'XLS_KEY'
    OUTPUT_GPKG = 'OUTPUT_GPKG'

    def name(self):
        return 'preencher_de_semente_core'

    def displayName(self):
        return 'Preencher e Padronizar (Modelo Semente)'

    def group(self):
        return 'Ferramentas de Padronização'

    def groupId(self):
        return 'padronizacao_tools'

    def createInstance(self):
        return PreencherDeSementeAlgorithm()

    # ------------------------------------------------------------------
    # Parâmetros do algoritmo (apenas camadas internas do QGIS)
    # ------------------------------------------------------------------
    def initAlgorithm(self, config=None):
        self.addParameter(
            QgsProcessingParameterVectorLayer(
                self.INPUT_LAYER,
                'Camada Vetorial de Entrada (Geometria)',
                [QgsProcessing.TypeVectorAnyGeometry]
            )
        )
        self.addParameter(
            QgsProcessingParameterVectorLayer(
                self.SEED_LAYER,
                'Camada Semente (Modelo) - carregada no QGIS',
                [QgsProcessing.TypeVectorAnyGeometry]
            )
        )
        self.addParameter(
            QgsProcessingParameterVectorLayer(
                self.TABLE_LAYER,
                'Tabela de Atributos (CSV carregado no QGIS)',
                [QgsProcessing.TypeVector]  # inclui NoGeometry carregada como "Texto Delimitado"
            )
        )
        self.addParameter(
            QgsProcessingParameterString(
                self.GIS_KEY, 'Campo Chave na Camada GIS', defaultValue='NOME'
            )
        )
        self.addParameter(
            QgsProcessingParameterString(
                self.XLS_KEY, 'Campo Chave na Tabela (CSV)', defaultValue='NOME'
            )
        )
        self.addParameter(
            QgsProcessingParameterFeatureSink(
                self.OUTPUT_GPKG, 'Saída (Camada Padronizada)'
            )
        )
        from qgis.core import QgsProcessingParameterBoolean
        self.addParameter(
            QgsProcessingParameterBoolean(
                "FILL_BAIRRO_OSM",
                "Preencher BAIRRO via OSM (Nominatim) — pode ser lento",
                defaultValue=True
            )
        )
    # ------------------------------------------------------------------
    # Lógica principal de execução
    # ------------------------------------------------------------------
    def processAlgorithm(self, parameters, context, feedback):
        # 1) Obter camadas
        vl_in = self.parameterAsVectorLayer(parameters, self.INPUT_LAYER, context)
        seed_layer = self.parameterAsVectorLayer(parameters, self.SEED_LAYER, context)
        tbl_layer = self.parameterAsVectorLayer(parameters, self.TABLE_LAYER, context)
        if vl_in is None:
            raise QgsProcessingException("Selecione a camada vetorial de entrada (INPUT_LAYER).")
        if seed_layer is None:
            raise QgsProcessingException("Selecione a camada Semente (SEED_LAYER).")
        if tbl_layer is None:
            raise QgsProcessingException("Selecione a Tabela (TABLE_LAYER).")

        chave_gis = self.parameterAsString(parameters, self.GIS_KEY, context)
        chave_xls = self.parameterAsString(parameters, self.XLS_KEY, context)

        # --- descobrir encoding do CSV (provider do Texto Delimitado)
        csv_enc = "utf-8"
        try:
            csv_enc = (tbl_layer.dataProvider().encoding() or "utf-8")
        except Exception:
            pass
        feedback.pushInfo(f"Encoding detectado do CSV: {csv_enc}")

        # 2) Converter camadas para DataFrames
        feedback.pushInfo("Lendo camadas do QGIS (entrada, semente, tabela)...")
        df_in = _layer_to_dataframe(vl_in, want_geometry=True)

        # LER CSV DIRETO DO DISCO (não usar os valores já interpretados pelo QGIS)
        csv_path = _extract_csv_path_from_layer(tbl_layer)
        feedback.pushInfo(f"Lendo CSV direto do arquivo: {csv_path}")
        df_tbl = _read_csv_robust(csv_path, feedback=feedback)


        # --- Normalizar texto do df_tbl para unicode correto (antes de qualquer merge)
        #     (aplica apenas em colunas 'object' para não mexer em numéricos)
        for c in df_tbl.columns:
            if df_tbl[c].dtype == object:
                df_tbl[c] = df_tbl[c].map(lambda x: _to_unicode(x, enc_hint=csv_enc))

        # --- também normaliza df_in (camada GIS) por segurança, mas usando utf-8
        for c in df_in.columns:
            if c == "__geometry__":
                continue
            if df_in[c].dtype == object:
                df_in[c] = df_in[c].map(lambda x: _to_unicode(x, enc_hint="utf-8"))

        if chave_gis not in df_in.columns:
            raise QgsProcessingException(f"O campo '{chave_gis}' não existe na camada de entrada.")
        if chave_xls not in df_tbl.columns:
            raise QgsProcessingException(f"O campo '{chave_xls}' não existe na tabela CSV.")

        # 3) Padronizar chaves e merge
        df_in["__key__"] = df_in[chave_gis].astype(str).str.strip()
        df_tbl["__key__"] = df_tbl[chave_xls].astype(str).str.strip()
        df_join = pd.merge(df_in, df_tbl, on="__key__", how="left")

        # 4) Esquema/tipo de geometria e CRS
        seed_fields = seed_layer.fields()
        fields_out = QgsFields()

        for f in seed_fields:
            nf = QgsField(
                f.name(),
                f.type(),
                f.typeName(),
                f.length(),
                f.precision(),
                f.comment()
            )
            nf.setAlias(f.alias())
            fields_out.append(nf)

        seed_wkb = seed_layer.wkbType()
        in_wkb = vl_in.wkbType()

        if QgsWkbTypes.geometryType(seed_wkb) in (QgsWkbTypes.NullGeometry, QgsWkbTypes.NoGeometry):
            wkb_out = in_wkb
            geom_exp = _expected_geom_from_layer(vl_in)
            feedback.pushWarning(
                f"Semente sem geometria. Usando tipo da entrada: {QgsWkbTypes.displayString(in_wkb)}"
            )
        else:
            wkb_out = seed_wkb
            geom_exp = _expected_geom_from_layer(seed_layer)

        # CRS de saída = CRS da camada de entrada
        crs_in = vl_in.crs()
        crs_out = crs_in

        feedback.pushInfo(
            "Geometrias/CRS — "
            f"Seed: {QgsWkbTypes.displayString(seed_wkb)} | "
            f"Input: {QgsWkbTypes.displayString(in_wkb)} | "
            f"Saída: {QgsWkbTypes.displayString(wkb_out)}"
        )

        # 5) Criar camada de saída
        sink, dest_id = self.parameterAsSink(
            parameters,
            self.OUTPUT_GPKG,
            context,
            fields_out,
            wkb_out,
            crs_out
        )
        if sink is None:
            raise QgsProcessingException("Não foi possível criar a camada de saída.")
        
        # ------------------------------------------------------------
        # Preparar cálculo de métricas geométricas (área/perímetro/len)
        # ------------------------------------------------------------
        # Mapa nome->índice (pra setAttribute ficar rápido)
        field_index = {fields_out.at(i).name(): i for i in range(fields_out.count())}

        # ------------------------------------------------------------
        # Preparar preenchimento de BAIRRO via Nominatim (opcional)
        # ------------------------------------------------------------
        idx_bairro = field_index.get("BAIRRO", None)

        fill_bairro = self.parameterAsBool(parameters, "FILL_BAIRRO_OSM", context)

        # Se o usuário ativou, mas o modelo semente não tem o campo, avisa e desliga
        if fill_bairro and idx_bairro is None:
            feedback.pushWarning(
                "Preenchimento de BAIRRO via OSM ativado, mas o campo 'BAIRRO' NÃO existe no modelo semente "
                "(schema da saída). Adicione 'BAIRRO' ao GPKG semente para habilitar o preenchimento."
            )
            fill_bairro = False

        bairro_cache = {}

        def _is_empty_for_fill(v):
            v = _clean_empty(v)
            if v is None:
                return True
            if isinstance(v, str) and v.strip() == "":
                return True
            return False

        # Só inicializa geopy se realmente for usar (evita travar plugin quando desligado)
        reverse = None
        to_wgs84 = None
        if fill_bairro:
            try:
                from geopy.geocoders import Nominatim
                from geopy.extra.rate_limiter import RateLimiter
                from qgis.core import QgsCoordinateReferenceSystem

                geolocator = Nominatim(user_agent="padrao_cliente_bairro")
                reverse = RateLimiter(geolocator.reverse, min_delay_seconds=1, swallow_exceptions=True)

                to_wgs84 = QgsCoordinateTransform(
                    crs_out,
                    QgsCoordinateReferenceSystem("EPSG:4326"),
                    QgsProject.instance()
                )
                feedback.pushInfo("BAIRRO/OSM: Nominatim inicializado.")
            except Exception as e:
                feedback.pushWarning(f"BAIRRO/OSM: falha ao inicializar geocoder ({e}). Desativando.")
                fill_bairro = False

        def _bairro_from_point(lat, lon):
            key = (round(lat, 4), round(lon, 4))
            if key in bairro_cache:
                return bairro_cache[key]

            if reverse is None:
                return None

            try:
                loc = reverse((lat, lon), language="pt")
                if not loc or "address" not in loc.raw:
                    bairro_cache[key] = None
                    return None
                addr = loc.raw["address"]
                bairro = (
                    addr.get("suburb")
                    or addr.get("neighbourhood")
                    or addr.get("city_district")
                    or addr.get("quarter")
                    or addr.get("village")
                    or addr.get("town")
                )
                bairro_cache[key] = bairro
                return bairro
            except Exception:
                bairro_cache[key] = None
                return None


        idx_area_ha = field_index.get("AREA_HA", None)
        idx_shape_area = field_index.get("Shape__Area", None)
        idx_shape_len = field_index.get("Shape__Length", None)
        idx_extensao = field_index.get("EXTENSAO", None)

        fill_bairro = self.parameterAsBool(parameters, "FILL_BAIRRO_OSM", context)

        idx_bairro = field_index.get("BAIRRO", None)  # ou "BAIRRO" conforme o seed
        bairro_cache = {}  # {(lat,lon): "Centro", ...}

        # rate limit (1s é o padrão “gentil”)
        bairro_delay_s = 0.5
        # arredondamento do cache
        bairro_cache_casas = 5

        # user agent fixo (pode colocar nome da empresa / plugin)
        bairro_user_agent = "padrao_cliente_qgis (bairro lookup)"


        # Configura medição (funciona bem tanto em CRS projetado quanto geográfico)
        dist = QgsDistanceArea()
        dist.setSourceCrs(crs_out, context.transformContext())

        ellps = QgsProject.instance().ellipsoid()
        if not ellps:
            ellps = "WGS84"
        dist.setEllipsoid(ellps)

        transformer = None
        if crs_in.isValid() and crs_out.isValid() and crs_in != crs_out:
            transformer = QgsCoordinateTransform(crs_in, crs_out, QgsProject.instance())

        sem_geom = 0
        total = len(df_join)

        transformer = None
        if crs_in.isValid() and crs_out.isValid() and crs_in != crs_out:
            transformer = QgsCoordinateTransform(crs_in, crs_out, QgsProject.instance())

        sem_geom = 0
        total = len(df_join)

        # 6) Loop de features
        for i, row in enumerate(df_join.itertuples(index=False, name=None)):
            if feedback.isCanceled():
                break
            if total:
                feedback.setProgress(int(i / total * 100))

            row_dict = dict(zip(df_join.columns, row))

            shp = row_dict.get("__geometry__", None)
            shp_adj = _ajustar_geom_para_tipo(shp, geom_exp)

            attrs = []
            for fld in fields_out:
                name = fld.name()
                qvtype = fld.type()

                raw_val = _pick(row_dict, name)

                # 🔎 DEBUG DE ENCODING (TEMPORÁRIO)
                if name.upper() == "DESCRICAO" and i == 0:
                    feedback.pushInfo(f"DEBUG raw_val (repr): {raw_val!r}")
                    try:
                        if isinstance(raw_val, str):
                            feedback.pushInfo(
                                f"DEBUG raw_val utf8 bytes: {raw_val.encode('utf-8', errors='replace')}"
                            )
                    except Exception as e:
                        feedback.pushInfo(f"DEBUG erro encoding: {e}")
                # 🔎 FIM DEBUG

                raw_val = _clean_empty(raw_val)


                if raw_val in (None, "", " ") and name.upper() in ("OBJECTID", "ID", "OID"):
                    coerced = i + 1
                else:
                    coerced = _coerce_to_type(raw_val, qvtype)

                if coerced == "" and qvtype in (QVariant.Date, QVariant.DateTime, QVariant.Time):
                    coerced = None
                if coerced == "":
                    coerced = None

                if coerced is not None and isinstance(coerced, str):
                    max_len = fld.length()
                    if max_len and max_len > 0 and len(coerced.encode("utf-8")) > max_len:
                        feedback.pushWarning(f"Campo '{name}' truncado para {max_len} bytes.")
                        coerced = _truncate_utf8_safe(coerced, max_len)

                attrs.append(coerced)

            feat = QgsFeature(fields_out)
            for idx, val in enumerate(attrs):
                feat.setAttribute(idx, val)

            if shp_adj is not None:
                try:
                    if hasattr(shp_adj, "is_valid") and not shp_adj.is_valid:
                        shp_adj = shp_adj.buffer(0)

                    qgs_geom = QgsGeometry.fromWkt(shp_adj.wkt)

                    if QgsWkbTypes.isMultiType(wkb_out) and not qgs_geom.isMultipart():
                        qgs_geom.convertToMultiType()

                    if transformer:
                        qgs_geom.transform(transformer)

                    if not qgs_geom.isEmpty():
                        feat.setGeometry(qgs_geom)
                except Exception:
                    pass

            # ------------------------------------------------------------
            # Preencher BAIRRO via OSM (somente se habilitado e se vazio)
            # ------------------------------------------------------------
            if fill_bairro and idx_bairro is not None and feat.hasGeometry():
                # só preenche se estiver vazio
                if _is_empty_like(feat.attribute(idx_bairro)):
                    lat, lon = _geom_to_latlon_wgs84(feat.geometry(), crs_out, context)

                    k = _coord_cache_key(lat, lon, casas=bairro_cache_casas)
                    if k is not None:
                        if k in bairro_cache:
                            bairro = bairro_cache[k]
                        else:
                            bairro = None
                            try:
                                bairro = _nominatim_reverse(
                                    lat, lon,
                                    language="pt",
                                    user_agent=bairro_user_agent,
                                    timeout=20
                                )
                            except Exception as e:
                                # não quebra o algoritmo por causa da internet
                                feedback.pushWarning(f"Falha ao buscar BAIRRO (OSM) em {k}: {e}")

                            bairro_cache[k] = bairro

                            # respeita rate limit APENAS quando fez chamada externa
                            time.sleep(bairro_delay_s)

                        if bairro:
                            feat.setAttribute(idx_bairro, bairro)

            
            # ------------------------------------------------------------
            # Calcular AREA_HA / Shape__Area / Shape__Length / EXTENSAO
            # ------------------------------------------------------------
            if feat.hasGeometry() and (
                idx_area_ha is not None
                or idx_shape_area is not None
                or idx_shape_len is not None
                or idx_extensao is not None
            ):
                g = feat.geometry()
                gtype = QgsWkbTypes.geometryType(g.wkbType())

                area_m2 = None
                length_m = None

                if gtype == QgsWkbTypes.PolygonGeometry:
                    area_m2 = dist.measureArea(g)
                    length_m = dist.measurePerimeter(g)
                elif gtype == QgsWkbTypes.LineGeometry:
                    length_m = dist.measureLength(g)

                # Shape__Area (m²) — só preenche se estiver vazio
                if idx_shape_area is not None and _is_empty_like(feat.attribute(idx_shape_area)):
                    feat.setAttribute(idx_shape_area, area_m2)

                # AREA_HA (hectares) — só preenche se estiver vazio
                if idx_area_ha is not None and _is_empty_like(feat.attribute(idx_area_ha)):
                    feat.setAttribute(
                        idx_area_ha,
                        (area_m2 / 10000.0) if area_m2 is not None else None
                    )

                # Shape__Length (m) — só preenche se estiver vazio
                if idx_shape_len is not None and _is_empty_like(feat.attribute(idx_shape_len)):
                    feat.setAttribute(idx_shape_len, length_m)

                # EXTENSAO — só preenche se estiver vazio
                if idx_extensao is not None and _is_empty_like(feat.attribute(idx_extensao)):
                    feat.setAttribute(idx_extensao, length_m)
            # ------------------------------------------------------------
            # Preencher BAIRRO via OSM (somente se vazio no CSV)
            # - Polígono  → pointOnSurface()
            # - Linha     → primeiro vértice
            # - Ponto     → próprio ponto
            # ------------------------------------------------------------
            if fill_bairro and idx_bairro is not None and feat.hasGeometry():
                atual = feat.attribute(idx_bairro)
                if _is_empty_for_fill(atual):
                    try:
                        g = feat.geometry()
                        if g is None or g.isEmpty():
                            raise Exception("geometria vazia")

                        gtype = QgsWkbTypes.geometryType(g.wkbType())

                        # POLÍGONO → point on surface
                        if gtype == QgsWkbTypes.PolygonGeometry:
                            p = g.pointOnSurface().asPoint()

                        # LINHA ou PONTO → primeiro vértice
                        else:
                            it = g.vertices()
                            p = next(it, None)
                            if p is None:
                                raise Exception("sem vertices")

                        # Transformar para WGS84
                        if to_wgs84:
                            p = to_wgs84.transform(p)

                        lat = p.y()
                        lon = p.x()

                        bairro = _bairro_from_point(lat, lon)
                        if bairro:
                            feat.setAttribute(idx_bairro, bairro)

                    except Exception:
                        pass


            if not sink.addFeature(feat):
                sem_geom += 1
            elif not feat.hasGeometry():
                sem_geom += 1

        if sem_geom:
            feedback.pushWarning(f"{sem_geom} feição(ões) foram gravadas sem geometria.")

        feedback.pushInfo("Concluído: camada padronizada gerada.")
        return {self.OUTPUT_GPKG: dest_id}

