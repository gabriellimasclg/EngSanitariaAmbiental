# -*- coding: utf-8 -*-
"""
Created on Wed Nov 12 14:12:02 2025

@author: gabriel.coimbra
"""
import os, sys
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "vendor"))

from geopy.geocoders import Nominatim
from qgis.core import Qgis, QgsMessageLog


def classFactory(iface):
    """
    Retorna a classe principal do plugin para o QGIS.
    Faz checagem leve das dependências apenas quando o algoritmo for executado.
    """
    # Importar aqui evita erros de carregamento se bibliotecas estiverem ausentes
    from .preencher_semente import PreencherSemente

    try:
        # Tentativa simples de import para verificar se o ambiente está preparado
        import importlib
        for lib in ["pandas","shapely"]:
            importlib.import_module(lib)
    except ImportError as e:
        # Mostra aviso no painel de mensagens do QGIS, mas permite carregar o plugin
        QgsMessageLog.logMessage(
            f"Aviso: biblioteca ausente ({e.name}). "
            f"Alguns algoritmos podem não funcionar até que ela seja instalada.\n"
            f"Instale no Python do QGIS: pip install {e.name}",
            "Preencher Semente",
            Qgis.Warning
        )

    return PreencherSemente(iface)
