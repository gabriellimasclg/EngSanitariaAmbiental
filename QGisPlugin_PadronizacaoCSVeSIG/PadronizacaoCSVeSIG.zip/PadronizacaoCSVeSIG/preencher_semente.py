# -*- coding: utf-8 -*-
"""
Preencher Semente - Provider de Processamento
"""

import os

from qgis.PyQt.QtWidgets import QAction
from qgis.PyQt.QtGui import QIcon

from qgis.core import (
    QgsProcessingProvider,
    QgsApplication,
    QgsMessageLog,
    Qgis,
)

# Algoritmo
from .preenchimento_alg import PreencherDeSementeAlgorithm


class PadronizacaoProvider(QgsProcessingProvider):
    def id(self):
        # ID estável, sem espaços
        return "padronizacao_tools"

    def name(self):
        # Nome do grupo que aparece no Toolbox
        return "Ferramentas de Padronização"

    def longName(self):
        return self.name()

    def loadAlgorithms(self):
        # Registra seus algoritmos aqui
        self.addAlgorithm(PreencherDeSementeAlgorithm())


class PreencherSemente:
    """Classe principal do plugin (registrar/remover o provider e criar botão)."""

    def __init__(self, iface):
        self.iface = iface
        self.provider = None
        self.action = None

    def _abrir_preencher_semente(self):
        from qgis import processing
        processing.execAlgorithmDialog("padronizacao_tools:preencher_de_semente_core", {})


    def initGui(self):
        # --------------------------------------------------
        # 1) Registrar o Processing Provider
        # --------------------------------------------------
        try:
            self.provider = PadronizacaoProvider()
            QgsApplication.processingRegistry().addProvider(self.provider)

            QgsMessageLog.logMessage(
                "Provider 'Ferramentas de Padronização' registrado com sucesso.",
                "Preencher Semente",
                Qgis.Info
            )

        except Exception as e:
            QgsMessageLog.logMessage(
                f"Falha ao registrar provider: {e}",
                "Preencher Semente",
                Qgis.Critical
            )
            return  # sem provider, não faz sentido criar botão

        # --------------------------------------------------
        # 2) Criar ação/botão com ícone
        # --------------------------------------------------
        plugin_dir = os.path.dirname(__file__)
        icon_path = os.path.join(plugin_dir, "logo.png")

        self.action = QAction(
            QIcon(icon_path) if os.path.exists(icon_path) else QIcon(),
            "Preencher e Padronizar (Modelo Semente)",
            self.iface.mainWindow()
        )

        self.action.setWhatsThis(
            "Abre diretamente o algoritmo Preencher e Padronizar (Modelo Semente)."
        )

        self.action.triggered.connect(self._abrir_preencher_semente)

        # --------------------------------------------------
        # 3) Adicionar ao menu e toolbar
        # --------------------------------------------------
        self.iface.addPluginToMenu("Ferramentas de Padronização", self.action)
        self.iface.addToolBarIcon(self.action)

    def unload(self):
        # Remove botão
        if self.action:
            try:
                self.iface.removeToolBarIcon(self.action)
                self.iface.removePluginMenu("Ferramentas de Padronização", self.action)
            except Exception:
                pass
            self.action = None

        # Remove provider
        if self.provider:
            try:
                QgsApplication.processingRegistry().removeProvider(self.provider)
                QgsMessageLog.logMessage(
                    "Provider 'Ferramentas de Padronização' removido.",
                    "Preencher Semente",
                    Qgis.Info
                )
            except Exception as e:
                QgsMessageLog.logMessage(
                    f"Falha ao remover provider: {e}",
                    "Preencher Semente",
                    Qgis.Warning
                )
            self.provider = None
